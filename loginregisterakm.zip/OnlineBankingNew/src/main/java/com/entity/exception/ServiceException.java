package com.entity.exception;

public class ServiceException {

}
